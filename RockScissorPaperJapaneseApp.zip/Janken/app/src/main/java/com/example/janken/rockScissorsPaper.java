package com.example.janken;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class rockScissorsPaper extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rock_scissors_pape);

        defineButtons();//<- make sure class is declared
    }

    public void defineButtons() {//finds buttons, then sets onClickListener
        findViewById(R.id.rock).setOnClickListener(buttonClickListener);
        findViewById(R.id.paper).setOnClickListener(buttonClickListener);
        findViewById(R.id.scissors).setOnClickListener(buttonClickListener);
        findViewById(R.id.homeButton).setOnClickListener(buttonClickListener);
        findViewById(R.id.vocabButton).setOnClickListener(buttonClickListener);
    }

    public View.OnClickListener buttonClickListener = new View.OnClickListener() {//creates onClick listener for view (phone screen)
        @Override
        public void onClick(View view) {//views the phone screen, then we switch the getId to create different choices for rock scissor paper

            switch (view.getId()) {
                case R.id.rock://0
                    if (compRandom() == 0) {
                        startActivity(new Intent(rockScissorsPaper.this, Tie.class));//go to tie screen (rock and rock)
                    } else if (compRandom() == 1) {
                        startActivity(new Intent(rockScissorsPaper.this, Win.class));//go to win screen
                    } else if (compRandom() == 2) {
                        startActivity(new Intent(rockScissorsPaper.this, Lose.class));//go to lose screen
                    }
                    break;

                case R.id.paper://2
                    if (compRandom() == 0) {
                        startActivity(new Intent(rockScissorsPaper.this, Win.class));//go to tie screen
                    } else if (compRandom() == 1) {
                        startActivity(new Intent(rockScissorsPaper.this, Lose.class));//go to win screen
                    } else if (compRandom() == 2) {
                        startActivity(new Intent(rockScissorsPaper.this, Tie.class));//go to lose screen (paper and paper)
                    }
                    break;

                case R.id.scissors://1
                    if (compRandom() == 0) {
                        startActivity(new Intent(rockScissorsPaper.this, Lose.class));//go to lose screen
                    } else if (compRandom() == 1) {
                        startActivity(new Intent(rockScissorsPaper.this, Tie.class));//go to tie screen (scissors and scissors)
                    } else if (compRandom() == 2) {
                        startActivity(new Intent(rockScissorsPaper.this, Win.class));//go to win screen
                    }
                    break;

                case R.id.homeButton://goes home
                    startActivity(new Intent(rockScissorsPaper.this, MainActivity.class));
                    break;

                case R.id.vocabButton://goes to vocab page
                    startActivity(new Intent(rockScissorsPaper.this, Vocab.class));
                    break;

                default:
            }
        }

        public int compRandom() {// 0(Rock), 1(scissors), 2(paper)
            Random random = new Random();
            return random.nextInt(3);
        }
    };
}
